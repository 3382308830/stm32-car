#ifndef __ULTRASOUND_H
#define __ULTRASOUND_H
void Ultrasound_Init();
float Test_Distance();
#endif